<?php

/**
 * @author Jonathan LeMaitre
 * @copyright 2013
 */

namespace Models\User;

class Account
{
	/** int */
	public $id;

	/** string */
	public $login_name;
	
	/** string */
	public $display_name;
}

?>